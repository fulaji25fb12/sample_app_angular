export class CourseModel {
    id?: number;
    name?: string;
}